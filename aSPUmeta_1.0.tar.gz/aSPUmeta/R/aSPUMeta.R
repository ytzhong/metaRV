aSPUMeta <- function(..., SNPInfo=NULL, snpNames, aggregateBy, pow = c(1:8,Inf), pow2 = c(1:8,Inf), n.perm=1e7) {
    cl <- match.call(expand.dots = FALSE)
    if(is.null(SNPInfo)){
        stop("No SNP Info file provided.")
    } else {
        SNPInfo <- prepSNPInfo(SNPInfo, snpNames, aggregateBy)
    }
    
    genelist <- stats::na.omit(unique(SNPInfo[,aggregateBy]))
    cohortNames <- lapply(cl[[2]],as.character)
    
    ncohort <- length(cohortNames)
    if (ncohort < 2)  {stop("Require more than 1 study")}
    
    ev <- parent.frame()
    classes <- unlist(lapply(cohortNames,function(name){class(get(name,envir=ev))}))
    if(!all(classes == "seqMeta" | classes == "skatCohort") ){
        stop("an argument to ... is not a seqMeta object!")
    }
    res.strings <- data.frame("gene"=genelist,stringsAsFactors=F)
    
    ncol.tmp = length(pow) * length(pow2) + 3
    res.numeric <- matrix(NA, nrow= nrow(res.strings),ncol =  ncol.tmp)
    
    ri <- 0
    snp.names.list <- split(SNPInfo[,snpNames],SNPInfo[,aggregateBy])
    
    for(gene in genelist){
        aspu.score <- NULL
        aspu.cov <-  matrix(NA,1,1)
        aspu.inf <- NULL
        ri <- ri+1
        nsnps.sub <- length(snp.names.list[[gene]])
        
        n.miss <- n.total <- mscores <- maf <- numeric(nsnps.sub)
        big.cov <- matrix(0, nsnps.sub,nsnps.sub)
        
        vary.ave <- 0
        cohort.count <- 1
        n.miss.cohort <- 0
        n.miss.snp <- 0
        n.snp <- 0
        snp.index <-1
        # the score function and its correspond variance are calculated using seqMeta package
        for(cohort.k in 1:ncohort){
            cohort.gene <- get(cohortNames[[cohort.k]],envir=ev)[[gene]]

            if(!is.null(cohort.gene)){
                sub <- match(snp.names.list[[gene]],colnames(cohort.gene$cov))
                if(any(is.na(sub)) | any(sub != 1:length(sub), na.rm=TRUE) | length(cohort.gene$maf) > nsnps.sub) {
                    cohort.gene$cov <- as.matrix(cohort.gene$cov)[sub,sub,drop=FALSE]
                    cohort.gene$cov[is.na(sub),] <- cohort.gene$cov[,is.na(sub)] <- 0
                    cohort.gene$maf <- cohort.gene$maf[sub]
                    cohort.gene$maf[is.na(sub)] <- -1
                    cohort.gene$scores <- cohort.gene$scores[sub]
                    cohort.gene$scores[is.na(sub)] <- 0
                } # fill the missing information
                
                tmp.cov <- as.matrix(cohort.gene$cov)
                
                tmp.index <- colSums(abs(tmp.cov)) == 0
                tmp.score <- cohort.gene$scores

                n.miss.snp <- n.miss.snp + sum(tmp.index)
                n.snp <- n.snp + sum(colSums(abs(tmp.cov)) != 0) 
                               
                aspu.score <- c(aspu.score,tmp.score/cohort.gene$sey^2)
                cov.tmp <-  as.matrix(tmp.cov/cohort.gene$sey^2)
                aspu.cov <- magic::adiag(aspu.cov, cov.tmp)
                
                snp.len = length(names(tmp.score))
                
                inf.tmp <- as.data.frame(matrix(NA,snp.len,2))
                colnames(inf.tmp) <- c("markname","gene.id")
                
                inf.tmp[,1] <- (snp.index):(snp.index + snp.len -1)
                
                snp.index <- snp.index + snp.len
                
                inf.tmp[,2] <- cohort.count
                cohort.count <- cohort.count + 1
                aspu.inf <- rbind(aspu.inf,inf.tmp)
                
            } else {
                n.miss.cohort <- n.miss.cohort + 1
            }
        }
        
        n.cohort <- ncohort - n.miss.cohort
        n.average.snp <- n.snp/n.cohort
        
        aspu.cov <- aspu.cov[-1,]
        aspu.cov <- aspu.cov[,-1]
        
        pvs = aSPUPath(U = aspu.score,V = aspu.cov,info = aspu.inf,pow = pow, pow2 = pow2,n.perm = 1000)
        
        if( min(pvs) < 10e-3 & 1000 < n.perm ) {
            pvs = aSPUPath(U = aspu.score,V = aspu.cov,info = aspu.inf,pow = pow, pow2 = pow2,n.perm = 1e4)
        }
        
        if( min(pvs) < 10e-4 & 1e4 < n.perm  ) {
            pvs = aSPUPath(U = aspu.score,V = aspu.cov,info = aspu.inf,pow = pow, pow2 = pow2,n.perm = 1e5)
        }
        
        
        if( min(pvs) < 10e-5 & 1e5 < n.perm ) {
            pvs = aSPUPath(U = aspu.score,V = aspu.cov,info = aspu.inf,pow = pow, pow2 = pow2,n.perm = 1e6)
        }
        
        if( min(pvs) < 10e-6 & 1e6 < n.perm) {
            pvs = aSPUPath(U = aspu.score,V = aspu.cov,info = aspu.inf,pow = pow, pow2 = pow2,n.perm = 1e7)
        }
        
        if( min(pvs) < 10e-7 & 1e7 < n.perm) {
            pvs = aSPUPath(U = aspu.score,V = aspu.cov,info = aspu.inf,pow = pow, pow2 = pow2,n.perm = 1e8)
        }
        
        res.numeric[ri,1] = n.cohort
        res.numeric[ri,2] = n.average.snp
        res.numeric[ri,3:(2+length(pvs))] = pvs
        
        colnames(res.numeric) = c("n.cohort","n.average.snp",names(pvs))
    }
    
    return(cbind(res.strings,res.numeric))
}
